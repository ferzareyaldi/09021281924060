-- phpMyAdmin SQL Dump
-- version 5.0.2
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Nov 16, 2020 at 01:49 PM
-- Server version: 10.4.14-MariaDB
-- PHP Version: 7.4.9

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `db-oprec`
--

-- --------------------------------------------------------

--
-- Table structure for table `alumni`
--

CREATE TABLE `alumni` (
  `nim` varchar(18) NOT NULL,
  `nama` text NOT NULL,
  `angkatan` int(11) NOT NULL,
  `tempat_lahir` text DEFAULT NULL,
  `tanggal_lahir` date DEFAULT NULL,
  `email` text DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `alumni`
--

INSERT INTO `alumni` (`nim`, `nama`, `angkatan`, `tempat_lahir`, `tanggal_lahir`, `email`) VALUES
('09021181924001', 'Fenny Utary', 2019, 'Palembang', '2002-01-21', 'fnyutr@gmail.com'),
('09021281924060', 'Ferza Reyaldi', 2019, 'Pendopo', '2000-04-04', 'reyaldiferza@gmail.com');

-- --------------------------------------------------------

--
-- Table structure for table `dosen`
--

CREATE TABLE `dosen` (
  `id_dosen` int(11) NOT NULL,
  `nidn` varchar(25) NOT NULL,
  `nama` varchar(100) NOT NULL,
  `gender` enum('Pria','Wanita') NOT NULL,
  `program_studi` varchar(40) NOT NULL,
  `alamat` text NOT NULL,
  `email` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `dosen`
--

INSERT INTO `dosen` (`id_dosen`, `nidn`, `nama`, `gender`, `program_studi`, `alamat`, `email`) VALUES
(2, 'IF003', 'M. FACHRURROZI, S.SI., M.T.', 'Pria', 'Teknik Informatika', 'Sumatera Selatan', 'if003@ilkom.unsri.ac.id'),
(3, 'IF002', 'MASTURA DIANA MARIESKA, M.T.', 'Wanita', 'Teknik Informatika', 'Sumatera Selatan', 'if002@ilkom.unsri.ac.id'),
(4, 'IF001', 'ALVI SYAHRINI UTAMI, M.KOM.', 'Wanita', 'Teknik Informatika', 'Sumatera Selatan', 'if001@ilkom.unsri.ac.id'),
(5, 'IF004', 'YUNITA, S.SI, M.CS.', 'Wanita', 'Teknik Informatika', 'Sumatera Selatan', 'if004@ilkom.unsri.ac.id'),
(6, 'IF005', 'RIZKI KURNIATI, M.T.', 'Wanita', 'Teknik Informatika', 'Sumatera Selatan', 'if005@ilkom.unsri.ac.id'),
(7, 'IF006', 'DESTY RODIAH, S.KOM., M.T.', 'Wanita', 'Teknik Informatika', 'Sumatera Selatan', 'if006@ilkom.unsri.ac.id'),
(8, 'IF007', 'DR. FITRI MAYA PUSPITA, M.SC', 'Wanita', 'Teknik Informatika', 'Sumatera Selatan', 'if007@ilkom.unsri.ac.id');

-- --------------------------------------------------------

--
-- Table structure for table `testimoni`
--

CREATE TABLE `testimoni` (
  `id_testimoni` int(11) NOT NULL,
  `tanggal` timestamp NOT NULL DEFAULT current_timestamp(),
  `nama` varchar(100) DEFAULT NULL,
  `angkatan` int(11) DEFAULT NULL,
  `konten` text DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `testimoni`
--

INSERT INTO `testimoni` (`id_testimoni`, `tanggal`, `nama`, `angkatan`, `konten`) VALUES
(1, '2020-10-11 17:14:55', 'Ferza', 2018, '\"Not able to tell you how happy I am with BEM Fasilkom. Thank You! BEM Fasilkom is awesome! We\'re loving it.\"'),
(2, '2020-10-11 17:14:55', 'Reyaldi', 2018, '\"Not able to tell you how happy I am with BEM Fasilkom. Thank You! BEM Fasilkom is awesome! We\'re loving it.\"'),
(3, '2020-10-11 17:15:26', 'Fenny', 2019, '\"Not able to tell you how happy I am with BEM Fasilkom. Thank You! BEM Fasilkom is awesome! We\'re loving it.\"'),
(4, '2020-10-11 17:15:26', 'Utary', 2019, '\"Not able to tell you how happy I am with BEM Fasilkom. Thank You! BEM Fasilkom is awesome! We\'re loving it.\"'),
(5, '2020-11-16 12:26:41', 'Aldi', 2017, '\"Not able to tell you how happy I am with BEM Fasilkom. Thank You! BEM Fasilkom is awesome! We\'re loving it.\"'),
(6, '2020-11-16 12:26:41', 'Fennut', 2017, '\"Not able to tell you how happy I am with BEM Fasilkom. Thank You! BEM Fasilkom is awesome! We\'re loving it.\"');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `alumni`
--
ALTER TABLE `alumni`
  ADD PRIMARY KEY (`nim`);

--
-- Indexes for table `dosen`
--
ALTER TABLE `dosen`
  ADD PRIMARY KEY (`id_dosen`);

--
-- Indexes for table `testimoni`
--
ALTER TABLE `testimoni`
  ADD PRIMARY KEY (`id_testimoni`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `dosen`
--
ALTER TABLE `dosen`
  MODIFY `id_dosen` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;

--
-- AUTO_INCREMENT for table `testimoni`
--
ALTER TABLE `testimoni`
  MODIFY `id_testimoni` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
