<!-- Main jumbotron for a primary marketing message or call to action -->
  <div class="container">
    <h1>Testimoni para Alumni</h2><br>
    <!-- Example row of columns -->
    <div class="row" id="konten">
      
    </div>

    <hr>

  </div> <!-- /container -->

  <script type="text/javascript">
    $(document).ready(function(){
        $.ajax({
          url: "<?php echo base_url();?>index.php/Oprec/getListTestimoni",
        }).done(function( res ) {
        let listTestimoni = JSON.parse(res);
        let konten = "";
        for ( i = 0; i < listTestimoni.length; i++){
          konten = ` ${konten}<div class='col-md-1'><img src="<?php echo base_url();?>assets/vector/student.svg" style="width:100%"></div><div class='col-md-5'><h2> ${listTestimoni[i]['nama']} (${listTestimoni[i]['angkatan']}) </h2><label> Uploaded : ${listTestimoni[i]['tanggal']} </label><p><em>${listTestimoni[i]['konten']}</em></p></div>`;
          }
          $("#konten").html(konten);
        });
    });
  </script>