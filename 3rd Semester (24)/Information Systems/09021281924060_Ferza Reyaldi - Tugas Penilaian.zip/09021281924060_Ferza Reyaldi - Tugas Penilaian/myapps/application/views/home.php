<!-- Main jumbotron for a primary marketing message or call to action -->
  <div class="jumbotron">
    <div class="container">
      <div class="row">
        <div class="col-md-6">
          <img src="<?php echo base_url();?>assets/img/logoUnsri.png" style="width:80%">
        </div>
        <div class="col-md-6">
          <h1>WELCOME TO SRIWIJAYA UNIVERSITY!</h1>
          <article style="text-align:justify">
            <p><strong>Sriwijaya University</strong> (Indonesian: Universitas Sriwijaya, abbreviated as UNSRI) is a research, teaching and learning center which has contributed significantly in the development and advancement of sciences, technologies, arts and cultures. Being one of the major state universities in Indonesia, Sriwijaya University's initial campus is located in Palembang, the capital of South Sumatera Province, and the second campus is located in Indralaya, approximately 32 km away from Palembang.</p>
            <p>UNSRI obtained accreditation "Very Good (A)" awarded by the National Accreditation Board of Higher Education (Indonesian: Badan Akrediasi Nasional Perguruan Tinggi, abbreviated as BAN-PT).</p>
          </article>
          <p><a class="btn btn-warning" href="https://en.wikipedia.org/wiki/Sriwijaya_University" role="button">View details &raquo;</a></p>
        </div>
      </div>
    </div>
  </div>